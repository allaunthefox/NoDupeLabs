# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2025 Allaun

"""File system walker for directory traversal.

This module provides file system traversal functionality using standard library only,
with support for filtering, progress tracking, and error handling.

Key Features:
    - Recursive directory traversal
    - File filtering by extension
    - Error handling with graceful degradation
    - Progress tracking support
    - Incremental scanning support

Dependencies:
    - os (standard library)
    - pathlib (standard library)
    - typing (standard library)
"""

import os
from pathlib import Path
from typing import List, Dict, Any, Optional, Callable
import time

class FileWalker:
    """File system walker for directory traversal.

    Responsibilities:
    - Traverse directory structures
    - Filter files by criteria
    - Handle file system errors gracefully
    - Support incremental scanning
    - Track progress
    """

    def __init__(self):
        """Initialize file walker."""
        self._file_count = 0
        self._dir_count = 0
        self._error_count = 0
        self._start_time = 0
        self._last_update = 0

    def walk(self, root_path: str, file_filter: Optional[Callable[[str], bool]] = None,
             on_progress: Optional[Callable[[Dict[str, Any]], None]] = None) -> List[Dict[str, Any]]:
        """Walk directory tree and return file information.

        Args:
            root_path: Root directory to start walking from
            file_filter: Optional function to filter files
            on_progress: Optional callback for progress updates

        Returns:
            List of file information dictionaries
        """
        self._reset_counters()
        self._start_time = time.time()
        self._last_update = self._start_time

        files = []
        root_path = str(Path(root_path).absolute())

        try:
            for dirpath, _, filenames in os.walk(root_path, followlinks=False):
                self._dir_count += 1

                for filename in filenames:
                    file_path = os.path.join(dirpath, filename)
                    relative_path = os.path.relpath(file_path, root_path)

                    try:
                        file_info = self._get_file_info(file_path, relative_path)

                        if file_filter is None or file_filter(file_info):
                            files.append(file_info)
                            self._file_count += 1

                        self._check_progress_update(on_progress)

                    except Exception as e:
                        self._error_count += 1
                        print(f"[WARNING] Error processing file {file_path}: {e}")

                # Update progress after each directory
                self._check_progress_update(on_progress)

        except Exception as e:
            print(f"[ERROR] Failed to walk directory {root_path}: {e}")
            raise

        return files

    def _get_file_info(self, file_path: str, relative_path: str) -> Dict[str, Any]:
        """Get file information for a single file.

        Args:
            file_path: Absolute file path
            relative_path: Relative file path

        Returns:
            Dictionary containing file information
        """
        try:
            stat = os.stat(file_path)

            return {
                'path': file_path,
                'relative_path': relative_path,
                'name': os.path.basename(file_path),
                'extension': os.path.splitext(file_path)[1].lower(),
                'size': stat.st_size,
                'modified_time': int(stat.st_mtime),
                'created_time': int(stat.st_ctime),
                'is_directory': False,
                'is_file': True,
                'is_symlink': os.path.islink(file_path)
            }
        except Exception as e:
            print(f"[WARNING] Error getting file info for {file_path}: {e}")
            raise

    def _check_progress_update(self, on_progress: Optional[Callable[[Dict[str, Any]], None]]) -> None:
        """Check if progress update should be sent.

        Args:
            on_progress: Optional progress callback
        """
        if on_progress is None:
            return

        current_time = time.time()
        if current_time - self._last_update >= 0.1:  # Update every 100ms
            self._last_update = current_time
            on_progress(self._get_progress())

    def _get_progress(self) -> Dict[str, Any]:
        """Get current progress information.

        Returns:
            Dictionary containing progress information
        """
        elapsed = time.time() - self._start_time
        return {
            'files_processed': self._file_count,
            'directories_processed': self._dir_count,
            'errors_encountered': self._error_count,
            'elapsed_time': elapsed,
            'files_per_second': self._file_count / elapsed if elapsed > 0 else 0
        }

    def _reset_counters(self) -> None:
        """Reset all counters."""
        self._file_count = 0
        self._dir_count = 0
        self._error_count = 0
        self._start_time = 0
        self._last_update = 0

    def get_statistics(self) -> Dict[str, Any]:
        """Get final statistics after walk completion.

        Returns:
            Dictionary containing final statistics
        """
        elapsed = time.time() - self._start_time
        return {
            'total_files': self._file_count,
            'total_directories': self._dir_count,
            'total_errors': self._error_count,
            'total_time': elapsed,
            'average_files_per_second': self._file_count / elapsed if elapsed > 0 else 0
        }

def create_file_walker() -> FileWalker:
    """Create and return a FileWalker instance.

    Returns:
        FileWalker instance
    """
    return FileWalker()
